Feito por: Guilherme Garcia Gloor

Compilar: 

gcc -o semaforo semaforo.c -lpthread -lrt 

executar: 

./semaforo

para textar, cole os numeros que estão no arquivo 100.txt ou 1000000.txt no in.txt para gerar o arquivo de saida in.out.txt

após a execução terminar, verificar o arquivo in.out.txt.